import pygame as pg
import random as rd
import time
from os import path
from settings import *
from sprites import *
from tilemap import *


class Game:
    def __init__(self, human = True):
        # initialize game window, etc
        pg.init()
        pg.mixer.init()
        self.screen = pg.display.set_mode((WIDTH, HEIGHT))
        pg.display.set_caption(TITLE)
        self.clock = pg.time.Clock()
        self.running = True
        self.human = human
        self.load_data()
        self.font_name = pg.font.match_font(FONT_NAME)
        self.space_sate = SPACESTATE

    def new(self):
        # start a new game
        self.all_sprites = pg.sprite.Group()
        self.ground = pg.sprite.Group()
        self.pipes = pg.sprite.Group()
        self.flag = pg.sprite.Group()
        self.font = pg.font.SysFont('Consolas', 30)
        self.reward = 0
        for row, tiles in enumerate(self.map.data):
            for col, tile in enumerate(tiles):
                if tile == '1':
                    Ground(self, col, row)
                if tile == 'P':
                    self.player = Player(self, col, row)
                if tile == '2':
                    Pipe(self, col, row)
                if tile == 'F':
                    Flag(self, col, row)
        self.camera = Camera(self.map.width, self.map.height)
        
        if self.human:
            self.run()
        else:
            self.start_ticks=pg.time.get_ticks()
            self.playing = True

    def load_data(self):
        game_folder = path.dirname(__file__)
        self.map = Map(path.join(game_folder, 'map.txt'))

    def run(self):
        # Game Loop
        self.playing = True
        self.start_ticks=pg.time.get_ticks()
        while self.playing:
            self.seconds=int((pg.time.get_ticks()-self.start_ticks)/1000) #calculate how many seconds
            self.clock.tick(FPS)
            self.events()
            self.update()
            self.draw()
        

    def update(self, action = 0):
        # Game Loop - Update
        if self.human:
            self.all_sprites.update()
        else:
            self.all_sprites.update(action)
        self.camera.update(self.player)
        hits_ground = pg.sprite.spritecollide(self.player, self.ground, False)
        if hits_ground:
            if self.player.vel.y > 0:
                self.player.pos.y = hits_ground[0].rect.top
                self.player.vel.y = 0
            elif self.player.vel.y < 0:
                self.player.pos.y = hits_ground[0].rect.bottom + self.player.rect.height
                self.player.vel.y = 0
        hits_pipe = pg.sprite.spritecollide(self.player, self.pipes, False)
        if hits_pipe:
            if self.player.vel.x > 0:
                self.player.pos.x = hits_pipe[0].rect.left - self.player.rect.width/2
                self.player.vel.x = 0
            elif self.player.vel.x < 0:
                self.player.pos.x = hits_pipe[0].rect.right + self.player.rect.width/2
                self.player.vel.x = 0
            """elif self.player.vel.y > 0:
                self.player.pos.y = hits_pipe[0].rect.top
                self.player.vel.y = 0
            elif self.player.vel.y < 0:
                self.player.pos.y = hits_pipe[0].rect.bottom + self.player.rect.height
                self.player.vel.y = 0"""
        hits_flag = pg.sprite.spritecollide(self.player, self.flag, False)
        if hits_flag:
            self.reward = self.get_reward(False,True)
            print("YOU WON\nSCORE:", self.reward)
            self.playing = False

        if self.player.pos.y > 385.2 + TILESIZE:
            self.reward = self.get_reward(True, False)
            print("GAMEOVER\nSCORE:", self.reward)
            self.playing = False
        if self.seconds == MAX_TIME:
            self.reward = self.get_reward(False, False)
            print("GAMEOVER\nSCORE:", self.reward)
            self.playing = False
        

    def events(self):
        # Game Loop - events
        for event in pg.event.get():
            # check for closing window
            if event.type == pg.QUIT:
                if self.playing:
                    self.playing = False
                self.running = False
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_SPACE:
                    self.player.jump()

    def get_reward(self, dead, end):
        reward = int(self.player.pos.x - self.player.pos_init.x) + self.seconds*2
        if dead:
            reward-=200
        elif end:
            reward+=1000
        return reward

    def draw(self):
        # Game Loop - draw
        self.screen.fill(BLACK)
        for sprite in self.all_sprites:
            self.screen.blit(sprite.image, self.camera.apply(sprite))
        self.draw_text(str(MAX_TIME - self.seconds), 22, WHITE, WIDTH / 2, 15)
        # *after* drawing everything, flip the display
        pg.display.flip()

    def show_start_screen(self):
        # game splash/start screen
        pass

    def show_go_screen(self):
        # game over/continue
        pass

    def draw_text(self, text, size, color, x, y):
        font = pg.font.Font(self.font_name, size)
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x, y)
        self.screen.blit(text_surface, text_rect)

    def step(self, action):
        # Game Loop
        #self.playing = True
        #while self.playing:
        self.seconds=int((pg.time.get_ticks()-self.start_ticks)/1000) #calculate how many seconds
        self.clock.tick(FPS)
        self.update(action)
        self.draw()
        return self.reward ,  self.playing


#ROBOT RUN
"""
g = Game(False)
g.show_start_screen()
g.new()
g.playing = True
while g.playing:
    #g.new()
    action = rd.choice([0,2,3,5])
    #time.sleep(0.2)
    print(action)
    g.step(action)
    #print("nao sai")
    g.show_go_screen()

pg.quit()
"""


#HUMAN RUN
"""
g = Game()
while g.running:
    g.new()
pg.quit()
"""