Para usar com a MCTS o que fazia:

1 - criar objecto Game com parametro false
2 - depois fazia Game.new() para criar um novo jogo
3 - Usava a função Game.step(action) que aplicava a acao no ambiente atual

As acoes que estao disponiveis de momento estao no settings.py.