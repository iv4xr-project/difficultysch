# Sprite Classes
import pygame as pg
from settings import *
vec = pg.math.Vector2

class Player(pg.sprite.Sprite):
    def __init__(self,game, x, y):
        self.groups = game.all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE,TILESIZE))
        self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH/2, HEIGHT/2)
        self.pos = vec(x, y) * TILESIZE
        self.vel = vec(0,0)
        self.acc = vec(0,0)
        self.pos_init = vec(x,y) * TILESIZE
    
    def jump(self):
        #jump only if standing
        self.rect.x +=1
        hits = pg.sprite.spritecollide(self, self.game.ground, False)
        self.rect.x -=1
        if hits:
            self.vel.y = -PLAYER_JUMP

    def update(self, action = 0):
        self.acc = vec(0,PLAYER_GRAV)

        if self.game.human:
            keys = pg.key.get_pressed()
            if keys[pg.K_LEFT] or keys[pg.K_a]:
                self.acc.x = -PLAYER_ACC
            if keys[pg.K_RIGHT] or keys[pg.K_d]:
                self.acc.x = PLAYER_ACC
        else:
            #print("yoooo")
            if action == 1:
                self.acc.x = -PLAYER_ACC
            elif action == 2:
                self.acc.x = PLAYER_ACC
            elif action == 3:
                self.jump()
            elif action == 4:
                self.acc.x = -PLAYER_ACC
                self.jump()
            elif action == 5:
                self.acc.x = PLAYER_ACC
                self.jump()
        
        #apply friction
        self.acc.x += self.vel.x * PLAYER_FRICTION
        #equations of motion
        self.vel += self.acc
        self.pos += self.vel + 0.5 * self.acc
        
        """#wrap around
        if self.pos.x > WIDTH:
            self.pos.x = 0
        if self.pos.x < 0:
            self.pos.x = WIDTH"""

        """self.rect.x = self.pos.x
        self.collide_with_walls('x')
        self.rect.y = self.pos.y
        self.collide_with_walls('y')"""

        self.rect.midbottom = self.pos
        #print(self.pos)
    
    # a0 - NOOP, a1 - left, a2 - right, a3 - jump, a4 - left+jump, a5 - right+jump
    def update_robot(self,action):
        self.acc = vec(0,PLAYER_GRAV)

        if action == 1:
            self.acc.x = -PLAYER_ACC
        elif action == 2:
            self.acc.x = PLAYER_ACC
        elif action == 3:
            self.jump()
        elif action == 4:
            self.acc.x = -PLAYER_ACC
            self.jump()
        elif action == 5:
            self.acc.x = PLAYER_ACC
            self.jump()
        
        #apply friction
        self.acc.x += self.vel.x * PLAYER_FRICTION
        #equations of motion
        self.vel += self.acc
        self.pos += self.vel + 0.5 * self.acc
        

        self.rect.midbottom = self.pos
        #print(self.pos)


    def collide_with_walls(self, dir):
        if dir == 'x':
            hits = pg.sprite.spritecollide(self, self.game.walls, False)
            if hits:
                if self.vel.x > 0:
                    self.pos.x = hits[0].rect.left - self.rect.width
                if self.vel.x < 0:
                    self.pos.x = hits[0].rect.right
                self.vel.x = 0
                self.rect.x = self.pos.x
        if dir == 'y':
            hits = pg.sprite.spritecollide(self, self.game.walls, False)
            if hits:
                print("col detect")
                if self.vel.y > 0:
                    self.pos.y = hits[0].rect.top - self.rect.height
                if self.vel.y < 0:
                    self.pos.y = hits[0].rect.bottom
                self.vel.y = 0
                self.rect.y = self.pos.y

    
class Ground(pg.sprite.Sprite):
    def __init__(self,game, x, y):
        self.groups = game.all_sprites, game.ground
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE,TILESIZE))
        self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        self.rect.x = x * TILESIZE
        self.rect.y = y * TILESIZE

class Pipe(pg.sprite.Sprite):
    def __init__(self,game, x, y):
        self.groups = game.all_sprites, game.pipes
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE,TILESIZE))
        self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        self.rect.x = x * TILESIZE
        self.rect.y = y * TILESIZE

class Flag(pg.sprite.Sprite):
    def __init__(self,game, x,y):
        self.groups = game.all_sprites, game.flag
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE,TILESIZE))
        self.image.fill(WHITE)
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        self.rect.x = x * TILESIZE
        self.rect.y = y * TILESIZE